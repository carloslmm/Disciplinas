Hands-on 02: Caracterização de canal banda estreita (modelagem e caracterização do desvanecimento de pequena escala)
Entregas 01: Análise de uma medição real (caracterização de canais banda estreita)
O código contém os códigos da entrega 01. Para execução do código, basta rodar o arquivo "entrega_01.m" no matlab. Para mudar o modelo de propagação, necessitar mudar a variável dMPg de acordo com o modelo de propagação desejado.
O vídeo explicativo do hands-on está no link: https://youtu.be/eI7Vit8uUvs.
