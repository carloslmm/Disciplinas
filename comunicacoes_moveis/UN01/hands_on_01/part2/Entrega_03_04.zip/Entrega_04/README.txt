Hands-on 01: Uso de modelos de propagação para análises sistêmicas
Parte 02: Modelagem da cobertura celula com sombreamento
Entregas 04 ("Modelagem e avaliação da inclusão de microcélulas")
O código contém os códigos da entrega 04. Para execução do código, basta rodar o arquivo "entrega_04.m" no matlab.
O vídeo explicativo do hands-on está no link: https://youtu.be/DDph7oWChkE.
