Hands-on 01: Uso de modelos de propagação para análises sistêmicas
Parte 02: Modelagem da cobertura celula com sombreamento
Entregas 03 ("Comprovação do fator de ajuste do desvio padrão do sombreamento correlacionado")
O código contém os códigos da entrega 03. Para execução do código, basta rodar o arquivo "entrega_03.m" no matlab.
O vídeo explicativo do hands-on está no link: https://youtu.be/DDph7oWChkE.
