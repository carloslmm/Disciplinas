Hands-on 01: Uso de modelos de propagação para análises sistêmicas
Parte 01: Avaliação de cobertura celular
Entregas 01 ("Definição de raio celular para uma Outage planejada") e 02 ("Ajuste do modelo de propagação")
O código contém os códigos da entrega 01 e entrega 02. Para execução do código, basta rodar o arquivo "entrega_1_entrega_2.m" no matlab. Para mudar o modelo de propagação, necessitar mudar a variável dMPg de acordo com o modelo de propagação desejado.
O vídeo explicativo do hands-on está no link: https://youtu.be/BHb8okZWevg.
